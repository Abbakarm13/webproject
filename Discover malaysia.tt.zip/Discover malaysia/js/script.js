// Main JavaScript for Discover Malaysia Website
document.addEventListener("DOMContentLoaded", function () {
  // Explore Now button functionality
  const exploreButton = document.querySelector('.hero .cta-button');
  if (exploreButton) {
    exploreButton.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = 'destinations.html';
    });
  }

  // Mobile menu functionality
  const navLinks = document.querySelector(".nav-links");
  const hamburger = document.createElement("button");
  hamburger.className = "hamburger";
  hamburger.innerHTML = '<i class="fas fa-bars"></i>';
  
  if (!document.querySelector(".hamburger")) {
    document.querySelector(".navbar").insertBefore(hamburger, navLinks);
  }

  hamburger.addEventListener("click", () => {
    navLinks.classList.toggle("active");
    hamburger.classList.toggle("active");
  });

  // Destination card hover effects
  const destinationCards = document.querySelectorAll('.destination-card');
  destinationCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.classList.add('hover');
    });
    card.addEventListener('mouseleave', () => {
      card.classList.remove('hover');
    });
  });

  // Search functionality
  const searchInput = document.querySelector('.search-input');
  const searchButton = document.querySelector('.search-button');
  const searchResults = document.createElement('div');
  searchResults.className = 'search-results';
  searchInput.parentNode.appendChild(searchResults);

  const destinations = [
    {
      title: "Kuala Lumpur",
      description: "Malaysia's bustling capital city",
      link: "destinations.html#kuala-lumpur"
    },
    {
      title: "Penang",
      description: "Cultural heritage and street food paradise",
      link: "destinations.html#penang"
    },
    {
      title: "Langkawi",
      description: "Beautiful beaches and island adventures",
      link: "destinations.html#langkawi"
    },
    {
      title: "Malacca",
      description: "Historical city with rich heritage",
      link: "destinations.html#malacca"
    },
    {
      title: "Sabah",
      description: "Nature and wildlife experiences",
      link: "destinations.html#sabah"
    },
    {
      title: "Cameron Highlands",
      description: "Tea plantations and cool climate",
      link: "destinations.html#cameron-highlands"
    }
  ];

  function performSearch(query) {
    if (!query) {
      searchResults.style.display = 'none';
      return;
    }

    const filteredResults = destinations.filter(dest => 
      dest.title.toLowerCase().includes(query.toLowerCase()) ||
      dest.description.toLowerCase().includes(query.toLowerCase())
    );

    displaySearchResults(filteredResults);
  }

  function displaySearchResults(results) {
    searchResults.innerHTML = '';
    
    if (results.length === 0) {
      searchResults.innerHTML = '<div class="no-results">No destinations found</div>';
    } else {
      results.forEach(result => {
        const resultItem = document.createElement('a');
        resultItem.href = result.link;
        resultItem.className = 'search-result-item';
        resultItem.innerHTML = `
          <h4>${result.title}</h4>
          <p>${result.description}</p>
        `;
        searchResults.appendChild(resultItem);
      });
    }
    
    searchResults.style.display = 'block';
  }

  // Search event listeners
  searchInput.addEventListener('input', (e) => {
    performSearch(e.target.value);
  });

  searchButton.addEventListener('click', (e) => {
    e.preventDefault();
    performSearch(searchInput.value);
  });

  // Close search results when clicking outside
  document.addEventListener('click', (e) => {
    if (!searchResults.contains(e.target) && !searchInput.contains(e.target)) {
      searchResults.style.display = 'none';
    }
  });

  // Newsletter form functionality
  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = newsletterForm.querySelector('input[type="email"]');
      const email = emailInput.value;
      
      // Simple email validation
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return;
      }

      // Success message
      alert('Thank you for subscribing! You will receive our latest updates soon.');
      emailInput.value = '';
    });
  }

  // Blog card interactions
  const blogCards = document.querySelectorAll('.blog-card');
  blogCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.classList.add('hover');
    });
    card.addEventListener('mouseleave', () => {
      card.classList.remove('hover');
    });

    // Make entire card clickable
    card.addEventListener('click', (e) => {
      if (!e.target.classList.contains('read-more')) {
        const link = card.querySelector('.read-more').href;
        window.location.href = link;
      }
    });
  });

  // Smooth scroll for navigation
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
});
